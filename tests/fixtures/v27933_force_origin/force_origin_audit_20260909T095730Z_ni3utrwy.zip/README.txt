Focused Force flag origin audit. Sources are read-only.
Original registry bytes and selected source code are preserved here.
No model files, no compiler execution, no cache changes.
This bundle can show current values/types and historical observations, not a missing edit history.
